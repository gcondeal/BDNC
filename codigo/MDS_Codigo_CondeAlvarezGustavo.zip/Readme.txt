Instrucciones de ejecución


Para la ejecucion del proceso es necesario que dentro de la ubicación del programa python (practica_bdnc.py) se cree una carpeta
data y en su interior se encuentre el fichero XML de datos, con el nombre dblp.xml .

Será necesario también una instancia de MongoDB ejecutándose en local en el puerto estandar 27017.

Una vez ejecutado el programa, este leerá el contenido del XML y dejará en la misma ruta, carpeta data, los cvs's que posteriormente se usan 
para la inserción de información en Neo4J.
 